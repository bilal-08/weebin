export class CodeDto {
    id:string;
    code:string;
    viewOnce:boolean;
}